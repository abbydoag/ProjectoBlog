function About() {
    return (
        <div>
            <h1 className="Title1">Sobre Nosotros</h1>
            <p>Esta página se creó con el fin de compartir escenas de una de mis series favoritas "RWBY". En especial 
                las peleas, ya que han sido una parte vital que caracteriza a la serie. No he encontrado nadie que la 
                vea en un ámbito de "la vida real", por lo que quiero impulsar que quienes si la vean compartan 
                sus escenas favoritas.
            </p>
            <div className="Media">
                <img src="src/assets/TeamRWBY.Gif" alt="TeamRWBY" />
            </div>
        </div>
    )
}

export default About